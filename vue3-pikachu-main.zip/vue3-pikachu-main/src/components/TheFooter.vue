<template>
    <div class="container">
        <p>
            Developed by Duong with Vue 3 in 13/05/2022 -
            <a href="https://github.com/duong261100/vue3-pikachu"
                >link github</a
            >
        </p>
    </div>
</template>

<style scoped>
.container {
    position: absolute;
    bottom: 0;
    color: var(--light);
}

p {
    font-size: 1.5rem;
    position: fixed;
    bottom: 50px;
    left: 50%;
    transform: translateX(-50%);
}

a {
    color: #f4dc26;
}
</style>
