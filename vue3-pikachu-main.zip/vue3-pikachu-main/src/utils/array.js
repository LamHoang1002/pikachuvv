export const shuffleArr = (arr) => arr.sort(() => Math.random() - 0.5);
