# vue3-pikachu

## Link demo

[vue3-pikachu](https://vue3-pikachu.herokuapp.com)

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm serve
```

### Compiles and minifies for production

```
npm build
```

### Lints and fixes files

```
yarn lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
